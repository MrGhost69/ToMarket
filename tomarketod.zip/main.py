import os
import urllib.parse


# ANSI escape codes for color
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def clear_terminal():
    # Clears the terminal
    os.system('cls' if os.name == 'nt' else 'clear')

def show_banner():
    # ASCII art and information
    ascii_art = f"""
{Colors.OKCYAN} __     __  __       _____ _               _   
 |  \/  |     / ____| |             | |  
 | \  / |_ __| |  __| |__   ___  ___| |_ 
 | |\/| | '__| | |_ | '_ \ / _ \/ __| __|
 | |  | | |_ | |__| | | | | (_) \__ \ |_ 
 |_|  |_|_(_) \_____|_| |_|\___/|___/\__|{Colors.ENDC}
"""
    print(ascii_art)
    print(f"{Colors.OKBLUE}--------------------------------------------------------------{Colors.ENDC}")
    print(f"{Colors.HEADER}Author   :- {Colors.BOLD}@MrGhostXBOT{Colors.ENDC}")
    print(f"{Colors.HEADER}Telegram :- Cyber Shield Force BD{Colors.ENDC}")
    print(f"{Colors.HEADER}Github   :- {Colors.BOLD}@MrGhost69{Colors.ENDC}")
    print(f"{Colors.HEADER}Tools    :- ToMarket Auto Game{Colors.ENDC}")
    print(f"{Colors.OKBLUE}--------------------------------------------------------------{Colors.ENDC}")

def redirect_to_telegram():
    # Redirect message to the Telegram channel
    os.system("xdg-open https://t.me/CSFTEAM3")

def url_decoder():
    # Prompts user for a URL, decodes it, and saves the data to a file
    print(f"{Colors.OKGREEN}\nEnter the encoded URL:{Colors.ENDC}")
    encoded_url = input("> ")

    base_url, fragment = encoded_url.split('#', 1) if '#' in encoded_url else (encoded_url, '')
    parsed_fragment = urllib.parse.parse_qs(fragment)

    tg_web_app_data_encoded = parsed_fragment.get('tgWebAppData', [''])[0]
    tg_web_app_data_decoded = urllib.parse.unquote(tg_web_app_data_encoded)
    
    print(f"{Colors.OKCYAN}\nDecoded tgWebAppData:{Colors.ENDC}")
    print(tg_web_app_data_decoded)

    if os.path.exists("data.txt"):
        os.remove("data.txt")
    
    with open("data.txt", "w") as file:
        file.write(tg_web_app_data_decoded)
        print(f"{Colors.OKBLUE}\nDecoded data saved to data.txt{Colors.ENDC}")

def main_menu():
    # Main menu with two options
    while True:
        print(f"{Colors.BOLD}\nSelect an option:{Colors.ENDC}")
        print(f"{Colors.OKGREEN}1. {Colors.ENDC}Collect User Data")
        print(f"{Colors.OKGREEN}2. {Colors.ENDC}Play Game")
        choice = input(f"{Colors.WARNING}\nEnter your choice (1 or 2): {Colors.ENDC}")

        if choice == '1':
            url_decoder()
            input(f"{Colors.OKBLUE}\nPress Enter to return to the main menu...{Colors.ENDC}")
            clear_terminal()
            show_banner()

        elif choice == '2':
            print(f"{Colors.OKCYAN}\nStarting the game...{Colors.ENDC}")
            # Assumes 'bot.py' is the game script
            os.system('python bot.py')
            input(f"{Colors.OKBLUE}\nPress Enter to return to the main menu...{Colors.ENDC}")
            clear_terminal()
            show_banner()
        else:
            print(f"{Colors.FAIL}\nInvalid choice. Please enter 1 or 2.{Colors.ENDC}")

# Main script execution
if __name__ == "__main__":
    clear_terminal()
    show_banner()
    redirect_to_telegram()
    main_menu()
